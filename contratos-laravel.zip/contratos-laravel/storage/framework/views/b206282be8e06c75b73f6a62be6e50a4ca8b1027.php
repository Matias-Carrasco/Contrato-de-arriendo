<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('/perfil')); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <section class="content">

    <div class="card card-primary container">
        <div class="card-header">
            <h3 class="card-title">Rellene los datos</h3>
        </div>
        <div class="card-body" style="display: block;">

            <div class="form-group">
                <label for="ID_contrato"><?php echo e('Contrato'); ?></label>
                <input type="hidden" value="<?php echo e($contrato->ID_contrato); ?>" id="ID_contrato">
            </div>

            <div class="card" id="cartita">

                <label for="ID_perfil">Seleccione Perfil</label>
                <select name="ID_perfil" id="ID_perfil">
                <option value="">-- Escoja Perfil --</option>
                <?php $__currentLoopData = $Perfiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($perfil->ID_perfil); ?>"><?php echo e($perfil->Nombre_perfil); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
                <label for="Cantidad">Cantidad</label>
                <input type="number" name="Cantidad" id="Cantidad">

                <input type="submit" value="Agregar Perfil" class="btn col-3 btn-success float-right">
            </div>

            
            <div class="row card-footer">
                <div class="col-12">
                    <a href="<?php echo e(url('/contrato')); ?>" class="btn btn-secondary">Cancel</a>
                    <input type="submit" value="Siguiente" class="btn btn-success float-right">
                </div>
            </div>
        </div>

    </div>

</section>
</form>
<?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
    <script>
        var contador = 0;

        function agregarP() {
            contador = contador + 1;
            console.log(contador);
            
            const divisor = document.createElement("div");
            divisor.className = "card";

            const contrato = document.createElement("input");
            contrato.type = "hidden";
            const contesp = <?php echo json_encode($contrato, 15, 512) ?>;
            contrato.value = contesp.ID_contrato;
            contrato.id = "ID_contrato"; 
            divisor.append(contrato); 

            const lab = document.createElement("label");
            lab.innerHTML = "Seleccione Perfil";
            divisor.append(lab);

            const salto = document.createElement("br");
            divisor.append(salto);

            const sel = document.createElement("select");
            sel.name = "ID_perfil[]";
            sel.id = "ID_perfil";
            divisor.append(sel);

            const opt = document.createElement('option');
            opt.text = "-- Escoja Perfil --";
            sel.append(opt);
            for (var x of <?php echo json_encode($Perfiles, 15, 512) ?>) {
                var optvar = document.createElement('option');
                optvar.value = x.ID_perfil;
                optvar.text = x.Nombre_perfil;
                sel.append(optvar);
            }

            divisor.append(salto);

            const lab2 = document.createElement("label");
            lab2.innerHTML = "Cantidad";
            divisor.append(lab2);
            divisor.append(salto);

            const inp = document.createElement("input");
            inp.type = "number";
            inp.name= "Cantidad[]"
            inp.value = "Cantidad";
            inp.id = "Cantidad";
            divisor.append(inp);
            

            document.getElementById('cartita').append(divisor);
        }

    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bastian/Documentos/Gitlab ContratoA/Contrato-de-Arriendos/contratos-laravel/resources/views/perfil/create.blade.php ENDPATH**/ ?>