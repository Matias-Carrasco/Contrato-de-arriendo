<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('/contrato')); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <section class="content">



        <div class="row">
            <div class="col-md-6">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Rellene los datos</h3>
                    </div>
                    <div class="card-body" style="display: block;">

                        <div class="form-group">
                            <label for="ID_representante"><?php echo e('Representante'); ?></label>
                            <select name="ID_representante" id="ID_representante"
                                class="form-control custom-select <?php echo e($errors->has('id')?'is-invalid':''); ?>">
                                <option value="">-- Escoja representante--</option>
                                <?php $__currentLoopData = $representantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $representante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($representante->ID_representante); ?>"> <?php echo e($representante->Nombre_re); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('ID_representante','<div class="invalid-feedback"> :message</div>'); ?>


                        </div>
                        <div class="form-group">
                            <label for="ID_proveedor"><?php echo e('Proveedor'); ?></label>
                            <select name="ID_proveedor" id="ID_proveedor"
                                class="form-control custom-select <?php echo e($errors->has('id')?'is-invalid':''); ?>">
                                <option value="">-- Escoja proveedor--</option>
                                <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($proveedor->ID_proveedor); ?>"> <?php echo e($proveedor->Nombre_pro); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('ID_proveedor','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>

                        <div class="form-group">
                            <label for="ID_estado"><?php echo e('Estado'); ?></label>
                            <select name="ID_estado" id="ID_estado"
                                class="form-control custom-select <?php echo e($errors->has('id')?'is-invalid':''); ?>">
                                <option value="">-- Escoja Estado--</option>
                                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($estado->ID_estado); ?>"> <?php echo e($estado->Descripcion); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('ID_estado','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>

                        <div class="form-group">
                            <label for="Fecha_inicial"><?php echo e('Fecha inicial'); ?></label>                           
                            <input type="date" name="Fecha_inicial" id="Fecha_inicial"
                                value="<?php echo e(isset($contrato->Fecha_inicial)?$contrato->Fecha_inicial:old('Fecha_inicial')); ?>"
                                class="form-control <?php echo e($errors->has('Fecha_inicial')?'is-invalid':''); ?>">
                            <?php echo $errors->first('Fecha_inicial','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>

                        <div class="form-group">
                            <label for="Fecha_termino"><?php echo e('Fecha termino'); ?></label>                           
                            <input type="date" name="Fecha_termino" id="Fecha_termino"
                                value="<?php echo e(isset($contrato->Fecha_termino)?$contrato->Fecha_termino:old('Fecha_termino')); ?>"
                                class="form-control <?php echo e($errors->has('Fecha_termino')?'is-invalid':''); ?>">
                            <?php echo $errors->first('Fecha_termino','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>

                        <div class="form-group">
                            <label for="PDF_base"><?php echo e('PDF base'); ?></label>
                            <input type="text" name="PDF_base" id="PDF_base"
                                value="<?php echo e(isset($contrato->PDF_base)?$anexo->PDF_base:old('PDF_base')); ?>"
                                class="form-control <?php echo e($errors->has('PDF_base')?'is-invalid':''); ?>">
                            <?php echo $errors->first('PDF_base','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>

                        <div class="form-group">
                            <label for="PDF_firmado"><?php echo e('PDF firmado'); ?></label>
                            <input type="text" name="PDF_firmado" id="PDF_firmado"
                                value="<?php echo e(isset($contrato->PDF_firmado)?$anexo->PDF_firmado:old('PDF_firmado')); ?>"
                                class="form-control <?php echo e($errors->has('PDF_firmado')?'is-invalid':''); ?>">
                            <?php echo $errors->first('PDF_firmado','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>

                        <div class="form-group">
                            <label for="Cod_licitacion"><?php echo e('Codigo licitacion'); ?></label>
                            <input type="text" name="Cod_licitacion" id="Cod_licitacion"
                                value="<?php echo e(isset($contrato->Cod_licitacion)?$anexo->Cod_licitacion:old('Cod_licitacion')); ?>"
                                class="form-control <?php echo e($errors->has('Cod_licitacion')?'is-invalid':''); ?>">
                            <?php echo $errors->first('Cod_licitacion','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>
                        

                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(url('/contrato')); ?>" class="btn btn-secondary">Cancel</a>
                <input type="submit" value="Siguiente" class="btn btn-success float-right">
            </div>
        </div>
    </section>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bastian/Documentos/Gitlab ContratoA/Contrato-de-Arriendos/contratos-laravel/resources/views/contrato/create.blade.php ENDPATH**/ ?>