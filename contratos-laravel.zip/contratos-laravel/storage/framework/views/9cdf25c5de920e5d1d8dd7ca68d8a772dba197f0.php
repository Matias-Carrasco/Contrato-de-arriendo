<?php $__env->startSection('content'); ?>
<div class="card">
    

    <div class="card-header">
        <h3 class="card-title">Clausula
            <a href="<?php echo e(url('/clausula/create')); ?>"class="btn btn-success d-flex ml-auto float-right">Crear clausula</a>
        </h3>
        
        
            
        
        
    </div>
    <div>
    <!-- /.card-header -->
    <div class="card-body table-responsive p-0" style="height: 700px;">
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0" style="height: 700px;">
            <table class="table table-head-fixed text-nowrap" id="tabla1">
                <thead>
                    <tr>
                        <th>Categoria</th>
                        <th>Descripcion</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $clausula; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($cat->ID_categoria ==$clau->ID_categoria): ?>
                                <td><?php echo e($cat->Descripcion); ?></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <td><?php echo e($clau->Descripcion); ?></td>
                        

                        <td>
                            <a href="<?php echo e(url('/clausula/'.$clau->ID_clausula.'/edit')); ?>">
                                <button type="submit" class="btn btn-block btn-warning"
                                    onclick="return confirm('Editar');">Editar</button>
                            </a>

                        </td>
                        <td>
                            <form method="post" action="<?php echo e(url('/clausula/'.$clau->ID_clausula)); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-block btn-danger"
                                    onclick="return confirm('Borrar');">Borrar</button>

                            </form>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                
            </table>
            



        </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bastian/Documentos/Gitlab ContratoA/Contrato-de-Arriendos/contratos-laravel/resources/views/clausula/index.blade.php ENDPATH**/ ?>