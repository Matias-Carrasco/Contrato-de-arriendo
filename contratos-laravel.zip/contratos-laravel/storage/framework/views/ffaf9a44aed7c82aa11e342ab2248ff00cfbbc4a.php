<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Proveedor</h3>
        <div>
            <a href="<?php echo e(url('/proveedor/create')); ?>"class="btn btn-success">Crear proveedor</a>
        </div>

    </div>
    <!-- /.card-header -->
    <div class="card-body table-responsive p-0" style="height: 700px;">
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0" style="height: 700px;">
            <table class="table table-head-fixed text-nowrap" id="tabla1">
                <thead>
                    <tr>
                        <th>Rut</th>
                        <th>Nombre</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $proveedor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pro->Rut_pro); ?></td>
                        <td><?php echo e($pro->Nombre_pro); ?></td>
                        

                        <td>
                            <a href="<?php echo e(url('/proveedor/'.$pro->ID_proveedor.'/edit')); ?>">
                                <button type="submit" class="btn btn-block btn-warning"
                                    onclick="return confirm('Editar');">Editar</button>
                            </a>

                        </td>
                        <td>
                            <form method="post" action="<?php echo e(url('/proveedor/'.$pro->ID_proveedor)); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-block btn-danger"
                                    onclick="return confirm('Borrar');">Borrar</button>

                            </form>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>




        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bastian/Documentos/Gitlab ContratoA/Contrato-de-Arriendos/contratos-laravel/resources/views/proveedor/index.blade.php ENDPATH**/ ?>