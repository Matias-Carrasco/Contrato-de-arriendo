<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('/anexo')); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <section class="content">



        <div class="row">
            <div class="col-md-6">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Rellene los datos</h3>
                    </div>
                    <div class="card-body" style="display: block;">

                        <div class="form-group">
                            <label for="ID_contrato"><?php echo e('Contrato'); ?></label>
                            <select name="ID_contrato" id="ID_contrato"
                                class="form-control custom-select <?php echo e($errors->has('id')?'is-invalid':''); ?>">
                                <option value="">-- Escoja contrato--</option>
                                <?php $__currentLoopData = $contratos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contrato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($contrato->ID_contrato); ?>"> <?php echo e($contrato->ID_contrato); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('ID_contrato','<div class="invalid-feedback"> :message</div>'); ?>


                        </div>
                        <div class="form-group">
                            <label for="ID_estado"><?php echo e('Estado'); ?></label>
                            <select name="ID_estado" id="ID_estado"
                                class="form-control custom-select <?php echo e($errors->has('id')?'is-invalid':''); ?>">
                                <option value="">-- Escoja estado--</option>
                                <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($estado->ID_estado); ?>"> <?php echo e($estado->Descripcion); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('ID_estado','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>
                        <div class="form-group">
                            <label for="PDF_anexo"><?php echo e('PDF anexo'); ?></label>
                            <input type="text" name="PDF_anexo" id="PDF_anexo"
                                value="<?php echo e(isset($anexo->PDF_anexo)?$anexo->PDF_anexo:old('PDF_anexo')); ?>"
                                class="form-control <?php echo e($errors->has('PDF_anexo')?'is-invalid':''); ?>">
                            <?php echo $errors->first('PDF_anexo','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(url('/anexo')); ?>" class="btn btn-secondary">Cancel</a>
                <input type="submit" value="Agregar" class="btn btn-success float-right">
            </div>
        </div>
    </section>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bastian/Documentos/Gitlab ContratoA/Contrato-de-Arriendos/contratos-laravel/resources/views/anexo/create.blade.php ENDPATH**/ ?>