<?php $__env->startSection('content'); ?>

<form  action="<?php echo e(url('/clausula')); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <section class="content">



        <div class=" container card">

                    <div class="card-header">
                        <h3 class="card-title">Rellene los datos</h3>
                    </div>
                    
        
                    <div class="" style="display: block;">

                        <div class="form-group">
                            <label for="ID_categoria"><?php echo e('Categoria'); ?></label>
                            <select name="ID_categoria" id="ID_categoria"
                                class="form-control custom-select <?php echo e($errors->has('id')?'is-invalid':''); ?>">
                                <option value="">-- Escoja categoria--</option>
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categoria->ID_categoria); ?>"> <?php echo e($categoria->ID_categoria); ?> -- <?php echo e($categoria->Descripcion); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('ID_categoria','<div class="invalid-feedback"> :message</div>'); ?>


                        </div>
                        
                        <div class="form-group">
                            <label for="Descripcion"><?php echo e('Descripcion'); ?></label>
                            <input type="text" name="Descripcion" id="Descripcion"
                                value="<?php echo e(isset($clausula->Descripcion)?$clausula->Descripcion:old('Descripcion')); ?>"
                                class="form-control <?php echo e($errors->has('Descripcion')?'is-invalid':''); ?>">
                            <?php echo $errors->first('Descripcion','<div class="invalid-feedback"> :message</div>'); ?>

                        </div>

                    </div>

        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(url('/clausula')); ?>" class="btn btn-secondary">Cancel</a>
                <input type="submit" value="Agregar" class="btn btn-success float-right">
            </div>
        </div>
    </div>
    </section>
</form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bastian/Documentos/Gitlab ContratoA/Contrato-de-Arriendos/contratos-laravel/resources/views/clausula/create.blade.php ENDPATH**/ ?>