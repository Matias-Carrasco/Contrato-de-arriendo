<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Representante_prov extends Model
{
    protected $primaryKey='ID_representante';
    public $timestamps = false;

}
