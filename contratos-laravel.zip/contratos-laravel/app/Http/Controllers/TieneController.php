<?php

namespace App\Http\Controllers;

use App\Models\Tiene;
use Illuminate\Http\Request;

class TieneController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tiene  $tiene
     * @return \Illuminate\Http\Response
     */
    public function show(Tiene $tiene)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tiene  $tiene
     * @return \Illuminate\Http\Response
     */
    public function edit(Tiene $tiene)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tiene  $tiene
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tiene $tiene)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tiene  $tiene
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tiene $tiene)
    {
        //
    }
}
